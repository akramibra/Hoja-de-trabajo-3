package GUI;
/*
* Universidad del Valle de Guatemala
* @author Akram Ibrahim
* Algoritmos y estructura de datos
*/
public class controlador {
    /***
	 * This method is used to play de program
	 */
    public void program(){
        //Importar cada una de las clases
        vista vista = new vista();
        LectorDatos leer = new LectorDatos();
        GnomeSort gnomeSort = new GnomeSort();
        SelectionSort selectionSort = new SelectionSort();
        quickSort quickst = new quickSort();
        radixSort radix = new radixSort();
        mergeSort merge = new mergeSort();

        int opcion = vista.menu1();    
        String numbers = leer.leerArchivo("datos.txt");    
        //Menu de Opciones
        switch(opcion){
            //Gnome Sort-------------------------------------------
            case 1:
                opcion = vista.menu2();
                switch(opcion){
                    case 1:
                        System.out.println("Gnome con 10 datos");
                        leer.Escribir("datos.txt",10);
                        gnomeSort.gnome();
                        break;                   
                    case 2:
                        System.out.println("Gnome con 100 datos");
                        leer.Escribir("datos.txt",100);
                        gnomeSort.gnome();
                        break;
                    case 3:
                        System.out.println("Gnome con 500 datos");
                        leer.Escribir("datos.txt",500);
                        gnomeSort.gnome();
                        break;     

                    case 4:
                        System.out.println("Gnome con 1000 datos");
                        leer.Escribir("datos.txt",1000);
                        gnomeSort.gnome();
                        break;           
                    case 5:
                        System.out.println("Gnome con 2000 datos");
                        leer.Escribir("datos.txt",2000);
                        gnomeSort.gnome();
                        break; 
                    case 6:
                        System.out.println("Gnome con 3000 datos");
                        leer.Escribir("datos.txt",3000);
                        gnomeSort.gnome();
                        break; 
                        default:
                        System.out.println("Error. Solo se pueden numeros del 1 al 10");
                        break;    
                }break;
            //Merge Sort------------------------------------------------------------
            case 2:
            opcion = vista.menu2();
            switch(opcion){
                case 1:
                    System.out.println("Merge con 10 datos");
                    leer.Escribir("datos.txt",10);
                    merge.merge();
                    break;                  
                case 2:
                    System.out.println("Merge con 100 datos");
                    leer.Escribir("datos.txt",100);
                    merge.merge();
                    break;
                case 3:
                    System.out.println("Merge con 500 datos");
                    leer.Escribir("datos.txt",500);
                    merge.merge();
                    break;          
                case 4:
                    System.out.println("Merge con 1000 datos");
                    leer.Escribir("datos.txt",1000);
                    merge.merge();
                    break;          
                case 5:
                    System.out.println("Merge con 2000 datos");
                    leer.Escribir("datos.txt",2000);
                    merge.merge();
                    break; 
                case 6:
                    System.out.println("Merge con 3000 datos");
                    leer.Escribir("datos.txt",3000);
                    merge.merge();
                    break; 
                    default:
                    System.out.println("Error. Solo se pueden numeros del 1 al 10");
                    break;
            }break;
            //Selection Sort--------------------------------------------------------
            case 3:
            opcion = vista.menu2();
            switch(opcion){
                case 1:
                    System.out.println("Selection con 10 datos");
                    leer.Escribir("datos.txt",10);
                    selectionSort.selection();
                    break;
                   
                case 2:
                    System.out.println("Selection con 100 datos");
                    leer.Escribir("datos.txt",100);
                    selectionSort.selection();
                    break;
                case 3:
                    System.out.println("Selection con 500 datos");
                    leer.Escribir("datos.txt",500);
                    selectionSort.selection();
                    break;     
      
                case 4:
                    System.out.println("Selection con 1000 datos");
                    leer.Escribir("datos.txt",1000);
                    selectionSort.selection();
                    break;       
                case 5:
                    System.out.println("Selection con 2000 datos");
                    leer.Escribir("datos.txt",2000);
                    selectionSort.selection();
                    break; 
                case 6:
                    System.out.println("Selection con 3000 datos");
                    leer.Escribir("datos.txt",3000);
                    selectionSort.selection();
                    break; 
                default:
                    System.out.println("Error. Solo se pueden numeros del 1 al 10");
                    break;
            }break;
            //Radix Sort----------------------------------------------------------------
            case 4:
            opcion = vista.menu2();
            switch(opcion){
                case 1:
                    System.out.println("Radix con 10 datos");
                    leer.Escribir("datos.txt",10);
                    radix.radix(leer.llamarArrayListaNormal(numbers));
                    break;                   
                case 2:
                    System.out.println("Radix con 100 datos");
                    leer.Escribir("datos.txt",100);
                    radix.radix(leer.llamarArrayListaNormal(numbers));
                    break;
                case 3:
                    System.out.println("Radix con 500 datos");
                    leer.Escribir("datos.txt",500);
                    radix.radix(leer.llamarArrayListaNormal(numbers));
                    break;          
                case 4:
                    System.out.println("Radix con 1000 datos");
                    leer.Escribir("datos.txt",1000);
                    radix.radix(leer.llamarArrayListaNormal(numbers));
                    break;          
                case 5:
                    System.out.println("Radix con 2000 datos");
                    leer.Escribir("datos.txt",2000);
                    radix.radix(leer.llamarArrayListaNormal(numbers));
                    break; 
                case 6:
                    System.out.println("Radix con 3000 datos");
                    leer.Escribir("datos.txt",3000);
                    radix.radix(leer.llamarArrayListaNormal(numbers));
                    break; 
                    default:
                    System.out.println("Error. Solo se pueden numeros del 1 al 10");
                    break;
            }break;
            //Quick Sort---------------------------------------------------------------
            case 5:
            opcion = vista.menu2();
            switch(opcion){
                case 1:
                    System.out.println("Quick con 10 datos");
                    leer.Escribir("datos.txt",10);
                    quickst.quick();
                    break;                     
                case 2:
                    System.out.println("Quick con 100 datos");
                    leer.Escribir("datos.txt",100);
                    quickst.quick();
                    break;
                case 3:
                    System.out.println("Quick con 500 datos");
                    leer.Escribir("datos.txt",500);
                    quickst.quick();
                    break;            
                case 4:
                    System.out.println("Quick con 1000 datos");
                    leer.Escribir("datos.txt",1000);
                    quickst.quick();
                    break;       
                case 5:
                    System.out.println("Quick con 2000 datos");
                    leer.Escribir("datos.txt",2000);
                    quickst.quick();
                    break; 
                case 6:
                    System.out.println("Quick con 3000 datos");
                    leer.Escribir("datos.txt",3000);
                    quickst.quick();
                    break; 
                    default:
                    System.out.println("Error. Solo se pueden numeros del 1 al 10");
                    break;
            }break;
            //Salir-----------------------------------------------------------------
            case 6:
                System.out.println("Finalizando programa...");
                System.exit(0);
            break;
            //En caso de errores
                default:
                System.out.println("Error. Solo se pueden numeros del 1 al 6");
            break;
                

        }
    }
}