package GUI;
public class main {

	public static void main(String[] args) {
		controlador controlador = new controlador();
        controlador.program();


	}

}

