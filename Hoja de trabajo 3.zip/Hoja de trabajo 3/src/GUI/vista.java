package GUI;
/*
* Universidad del Valle de Guatemala
* @author Akram Ibrahim
* Algoritmos y estructura de datos
*/

import java.util.Scanner;
public class vista {
    Scanner intscanner = new Scanner(System.in);
    /***
	 * This method is the sort menu
	 */
    public int menu1(){
        System.out.println("Escoja el tipo de algoritmo de ordenamiento para ordenar sus datos");
        System.out.println("1.Gnome Sort\n2.Merge Sort\n3.Selection Sort\n4.Radix Sort\n5.Quick Sort\n6.Salir\n");        
        int opcion = intscanner.nextInt();
        return opcion; 
    }
    /***
	 * This method is the menu for data
	 */
    public int menu2(){
        System.out.println("Escoja cuantos datos quiere analizar");
        System.out.println("1) 10\n2) 100\n3) 500\n4) 1000\n5) 2000\n6) 3000\n");
        int opcion = intscanner.nextInt();
        return opcion; 
    }
    
}
